# Fruit Ninja > 2024-08-08 8:47am
https://universe.roboflow.com/tyler-4yefm/fruit-ninja-bvono

Provided by a Roboflow user
License: CC BY 4.0

